package test;

import dao.CustomerDao;
import dto.Customer;
import service.CustomerService;
import service.ProductService;

import java.util.*;

public class OnlineShopTest {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        CustomerDao customerDao = new CustomerDao();
        CustomerService customerService = new CustomerService();
        ProductService productService = new ProductService();
        int input = 0;
        System.out.print("  Log in     - press 1" + "\n" + "new customer - press 2\n");
        try {
            input = scanner.nextInt();
            switch (input) {
                case 1: {
                    customerService.loginCustomer();
                    break;
                }
                case 2: {
                    Customer customer=customerService.customerRegister();
                    productService.executeMenu(customer);
                    break;
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("your input : " + input + " is invalid");
        }
    }

}
