package dao;

import dto.Products;

import java.sql.*;

public class ProductsDao {

    private Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlineshop"
                    , "root", null);
            return connection;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
        return null;
    }
    public void showProductsList() {
        try {
            Connection connection = getConnection();
            String query = "select * from products";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println("______products list_____");
            while (resultSet.next()) {

                String category = resultSet.getString("category");
                String name = resultSet.getString("name");
                double price = resultSet.getDouble("price");
                int stock = resultSet.getInt("stock");
                String brand = resultSet.getString("brand");
                System.out.println( "category : " + category + "\n" +
                        "product name :" + name + "\n" + "price :" + price + "\n" + "Brand :" +
                        brand + "\n" + "stock :" + stock);
                System.out.println("_______________________");
            }
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public Products searchProduct(String category,String name) {
        try {
            Connection connection = getConnection();
            String query = "select  * from  products where category = '" + category + "' and  name='" + name + "'";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            Products product = new Products();
            while (resultSet.next()) {
                product.setName(resultSet.getString("name"));
                product.setPrice(resultSet.getInt("price"));
                product.setBrand(resultSet.getString("brand"));
                product.setCategory(resultSet.getString("category"));
                product.setStock(resultSet.getInt("stock"));
            }
            preparedStatement.close();
            connection.close();
            return product;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public void updateProductsStock(String name, int itemCount) {
        try {
            Connection connection = getConnection();
            String query = "update products set products.stock =products.stock-? where  products.name like '" + name + "'";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, itemCount);
            preparedStatement.executeUpdate();
            System.out.println("products stock updated");
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void insertProduct(Products product) {
        try {
            Connection connection = getConnection();
            String query = "insert into products (product_id,category,price,stock,brand) values (?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, product.getProductId());
            preparedStatement.setString(2, product.getCategory());
            preparedStatement.setDouble(3, product.getPrice());
            preparedStatement.setInt(4, product.getStock());
            preparedStatement.setString(5, product.getBrand());
            preparedStatement.executeUpdate();
            System.out.println("successfully insert");
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
